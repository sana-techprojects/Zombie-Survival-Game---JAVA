Just want to share zombie characters with a chibi style, with animations (Idle, Walk, Attack, Hurt, and Dead)
I hope you like it



I also just released the game, let's try it :3 --> http://bit.ly/JutsuJump

By. Segel2D